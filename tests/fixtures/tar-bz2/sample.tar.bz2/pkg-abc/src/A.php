<?php
class A {}
